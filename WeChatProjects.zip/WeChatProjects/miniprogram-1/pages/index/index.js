Page({
  data:{
    isLoading:false,
    userInfo: null,
    config:null
  },
  onLogin() {
    if (this.data.isLoading) return;
    
    this.setData({ isLoading:true});

    this.WxLogin().then(this.getUserInfo)
    .then(this.sendLoginRequest).then(this.handleLoginSuccess)
  },
  WxLogin(){
    return new Promise((resolve, reject) => {
      wx.login({
        success: (res) => {
          if (res.code) {
            resolve(res.code);
          } else {
            reject (new Error('获取code失败'))
          }
        },
      })

    })
  },
  getUserInfo(code) {
   return new Promise ((resolve, reject) => {
     wx.getUserInfo({
      success: (res) => {
        resolve({
          code:code,
          encryptedData: res.encryptedData,
          iv: res.iv
        })
      }

     })
   })
  },
  sendLoginRequest(data){
    return new Promise ((resolve, reject) => {
      wx.request({
        url: 'http://127.0.0.1:5000/user/login',
        method: "POST",
        data:data,
        header:{
          'content-type':'application/json'
        },
        success:(res) => {
          if (res.statusCode === 200){
            resolve(res.data)
          } else{
            reject (new Error("服务器响应错误:" + res.statusCode));  
          }
        }
      })

    })
  },
  handleLoginSuccess(data) {
    console.log(data.userInfo) 
    // 更新页面数据
    this.setData({
      userInfo: data.userInfo,
      config:data.config
    });
    
    wx.showToast({
      title: data.msg,
      icon: "success"

    })
  }

})